-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 20, 2018 at 04:48 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz_ci`
--

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

DROP TABLE IF EXISTS `quiz`;
CREATE TABLE IF NOT EXISTS `quiz` (
  `quizID` int(50) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `choice1` varchar(255) NOT NULL,
  `choice2` varchar(255) NOT NULL,
  `choice3` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  PRIMARY KEY (`quizID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quizID`, `question`, `choice1`, `choice2`, `choice3`, `answer`) VALUES
(1, 'What is the capital of India', 'Lucknow', 'Mumbai', 'kolkata', 'Delhi'),
(2, 'Ramayan is written by..?', 'ved vyas', 'Ramanand Sagar', 'Kapil Dev', 'Tulsidas'),
(3, 'which city The Tajmahal is located', 'Jaipur', 'Burdwan', 'Delhi', 'Agra'),
(4, 'Who is Amitabh Bachhan', 'singer', 'Businessmen', 'Peon', 'Actor'),
(5, 'who is pm of india', 'Indira gandhi', 'Lalit Modi', 'Neerav Modi', 'Narendra Modi'),
(6, 'What is DSP ', 'Director Special Premium', 'Drive straight path', 'Deputy supp of Police', 'Digital signal processing'),
(7, 'who is leading run scorer in test cricket?', 'Lara', 'Laxman', 'Afridi', 'Sachin'),
(8, 'extends keyword is used for in programming?', 'extend any thing', 'represent an expression', 'an identifier', 'extend a class'),
(9, 'Google is a ?', 'A movie', 'an oil company', 'a landmark name in delhi', 'An IT company'),
(10, 'Times of india is a?', 'book', 'magzine', 'blog', 'newspaper');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
